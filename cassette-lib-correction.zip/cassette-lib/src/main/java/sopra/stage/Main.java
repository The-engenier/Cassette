package sopra.stage;

import java.util.Scanner;
@SuppressWarnings("java:S2189")
public class Main {
    private static final Scanner SC = new Scanner(System.in);
    private static final Scanner SC_STRING = new Scanner(System.in);
    private static final Cassette CASSETTE = new Cassette("C:\\Users\\LSBA\\Documents\\formations\\cassette-lib\\src\\main\\resources\\sample cassette.txt");

    public static void main(String[] args){
        while (true) {
            printMenu();
            int choice = SC.nextInt();
            switch (choice) {
                case 1 :
                    printChoiceChoosen("/----------LECTURE----------/");
                    CASSETTE.printCassetteData();
                    break;
                case 2 :
                    printChoiceChoosen("/-----------AJOUT-----------/");
                    processForSecondChoice();
                    break;
                case 3 :
                    printChoiceChoosen("/--------SUPPRESSION--------/");
                    processForThirdChoice();
                    break;
                case 4 :
                    printChoiceChoosen("/----------A PROPOS---------/");
                    System.out.println("Authored by Louis BALLAN");
                    System.out.println("Java 17");
                    break;
                case 5 :
                    printChoiceChoosen("/----------QUITTER----------/");
                    SC.close();
                    SC_STRING.close();
                    System.exit(0);
                default :
                    System.out.println("Choisissez une valeur de la liste");
                    printMenu();
            }
        }
    }

    private static void processForThirdChoice() {
        System.out.println("Nom de l'information à supprimer : ");
        int informationNumber = SC.nextInt();
        if (CASSETTE.isInformationNumberExisting(informationNumber)) {
            CASSETTE.printInformation(informationNumber);
            System.out.println("Voulez-vous vraiment supprimer cette information ? (O/N)");
            if (SC_STRING.nextLine().equals("O")) {
                CASSETTE.suppressInformation(informationNumber);
            }
        } else {
            System.out.println("L'information recherchée n'existe pas.");
        }
    }

    private static void processForSecondChoice() {
        System.out.println("Nom de l'information à ajouter : ");
        int informationNumber = SC.nextInt();
        if (CASSETTE.isInformationNumberCorrect(informationNumber)) {
            System.out.println("Information à sauvegarder : ");
            String message = SC_STRING.nextLine();
            if (CASSETTE.hasEnoughEmptySpace(message)) {
                CASSETTE.saveMessage(informationNumber, message);
            } else {
                System.out.println("La cassette ne possède pas assez d'espace de stockage libre");
            }
        } else {
            System.out.println("Le numéro de l'information est soit incorrect soit déjà utilisé");
        }
    }

    private static void printMenu() {
        System.out.println();
        System.out.println("1. Lecture");
        System.out.println("2. Ajout");
        System.out.println("3. Suppression");
        System.out.println("4. A propos");
        System.out.println("5. Quitter");
    }

    private static void printChoiceChoosen(String choice) {
        System.out.println();
        System.out.println(choice);
        System.out.println();
    }
}
