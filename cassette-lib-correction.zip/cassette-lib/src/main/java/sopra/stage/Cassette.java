package sopra.stage;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Cassette {
    private static String FILE_NAME;

    private List<Integer> data = new ArrayList<>();
    private List<Integer> table = new ArrayList<>();

    public Cassette(String cassetteFileName) {
        FILE_NAME = cassetteFileName;
        readCassette();
    }

    private void readCassette() {
        List<String> tempList = new ArrayList<>();
        try (BufferedReader br
                     = new BufferedReader(new InputStreamReader(new FileInputStream(FILE_NAME)))) {
            String line;
            while ((line = br.readLine()) != null) {
                tempList.addAll(Arrays.stream(line.split(",")).filter(e -> !e.isEmpty()).toList());
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        for (int i = 0; i < 1000; i++) {
            if (i < 800) {
                data.add(Integer.parseInt(tempList.get(i)));
            } else {
                table.add(Integer.parseInt(tempList.get(i)));
            }
        }
    }

    public void printCassetteData() {
        List<CassetteData> cassetteDataList = decodeCassetteDataContent();
        cassetteDataList.forEach(e -> System.out.printf("Information %d : %s%n", e.getInformationNumber(), e.getData()));
    }

    public void printInformation(int informationNumber) {
        List<CassetteData> cassetteDataList = decodeCassetteDataContent();
        CassetteData cassetteData = cassetteDataList.stream().filter(e -> e.getInformationNumber() == informationNumber).findFirst().orElse(null);
        System.out.printf("Information %d : %s%n", cassetteData.getInformationNumber(), cassetteData.getData());

    }
    public void suppressInformation(int informationNumber) {
        List<CassetteData> cassetteDataListWithoutSuppressedInfo = decodeCassetteDataContent()
                .stream()
                .filter(e -> e.getInformationNumber() != informationNumber)
                .toList();

        List<Integer> newDataList = new ArrayList<>();
        List<Integer> newTableList = new ArrayList<>();

        for (CassetteData cassetteData : cassetteDataListWithoutSuppressedInfo) {
            newDataList.addAll(encodeMessage(cassetteData.getData()));
            newTableList.add(cassetteData.getInformationNumber());
            newTableList.add(cassetteData.getData().length());
        }
        while (newTableList.size() < 200) {
            newTableList.add(0);
        }
        while (newDataList.size() < 800) {
            newDataList.add(0);
        }
        this.data = newDataList;
        this.table = newTableList;
        overwriteCassette();
    }

    public List<CassetteData> decodeCassetteDataContent() {
        List<CassetteData> cassetteDataList = new ArrayList<>();
        int cumulatedSizes = 0;
        for (int i = 0; i < table.size(); i += 2) {
            int dataNumber = table.get(i);
            if (dataNumber != 0) {
                int dataSize = table.get(i + 1);
                StringBuilder decodedData = new StringBuilder();
                List<Integer> encodedData = data.subList(cumulatedSizes, cumulatedSizes + dataSize);
                cumulatedSizes += dataSize;
                for (Integer encodedChar : encodedData) {
                    decodedData.append(Character.toString(encodedChar));
                }
                cassetteDataList.add(new CassetteData(dataNumber, decodedData.toString()));
            }
        }
        return cassetteDataList;
    }

    public boolean isInformationNumberExisting(int informationNumber) {
        return this.table.contains(informationNumber);

    }

    public boolean isInformationNumberCorrect(int informationNumber) {
        return informationNumber != 0 && !isInformationNumberExisting(informationNumber);
    }

    public void saveMessage(int informationNumber, String message){
        List<Integer> tempTable = this.table.stream().filter(e -> e != 0).collect(Collectors.toList());
        tempTable.add(informationNumber);
        tempTable.add(message.length());
        while (tempTable.size() < 200) {
            tempTable.add(0);
        }
        this.table = tempTable;

        List<Integer> tempData = data.stream().filter(e -> e != 0).collect(Collectors.toList());
        tempData.addAll(encodeMessage(message));
        while (tempData.size() < 800) {
            tempData.add(0);
        }
        this.data = tempData;
        overwriteCassette();
    }

    private List<Integer> encodeMessage(String message) {
        List<Integer> encodedMessage = new ArrayList<>();
        for (char c : message.toCharArray()) {
            encodedMessage.add((int) c);
        }
        return encodedMessage;
    }

    private void overwriteCassette() {
        StringBuilder str = new StringBuilder();

        int cpt = 0;

        for (Integer encodedChar : data) {
            str.append(encodedChar).append(",");
            cpt++;
            if (cpt == 20) {
                str.append("\n");
                cpt = 0;
            }
        }
        for (Integer tableInfo : table) {
            str.append(tableInfo).append(",");
            cpt++;
            if (cpt == 20) {
                str.append("\n");
                cpt = 0;
            }
        }
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            writer.write(str.toString());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public boolean hasEnoughEmptySpace(String messageToSave) {
        long dataEmptySpace = data.stream().filter(e -> e == 0).count();
        long tableEmptySpace = table.stream().filter(e -> e == 0).count();
        return messageToSave.length() <= dataEmptySpace && tableEmptySpace >= 2;
    }

    public List<Integer> getData() {
        return data;
    }

    public List<Integer> getTable() {
        return table;
    }
}
