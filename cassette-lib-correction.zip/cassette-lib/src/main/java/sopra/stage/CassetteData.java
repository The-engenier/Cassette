package sopra.stage;

import java.util.Objects;

public class CassetteData {
    private int informationNumber;
    private String data;

    public CassetteData(int informationNumber, String data) {
        this.informationNumber = informationNumber;
        this.data = data;
    }

    public int getInformationNumber() {
        return informationNumber;
    }


    public String getData() {
        return data;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CassetteData that = (CassetteData) o;
        return informationNumber == that.informationNumber && Objects.equals(data, that.data);
    }

    @Override
    public int hashCode() {
        return Objects.hash(informationNumber, data);
    }

    @Override
    public String toString() {
        return "Information " + informationNumber +
                " : " + data;
    }
}
